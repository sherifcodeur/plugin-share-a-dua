function sharePreviousLetexto(button) {
  console.log('✅ Clic détecté sur le bouton de partage.');

  const bigmaContainer = button.closest('.bigma');
  if (!bigmaContainer) {
    console.error('❌ Conteneur "bigma" non trouvé.');
    alert('Erreur : conteneur "bigma" manquant.');
    return;
  }

  const letextoElement = bigmaContainer.querySelector('.letexto');
  if (!letextoElement) {
    console.error('❌ Aucun ".letexto" trouvé dans le conteneur.');
    alert('Aucune duaa trouvée avec la classe "letexto".');
    return;
  }

  const text = letextoElement.innerText || letextoElement.textContent;
  const url = window.location.href;
  const fullText = `${text}\n\nPartagé depuis: ${url}`;

  console.log('📄 Duaa trouvée :', text);

  if (navigator.share) {
    navigator.share({ title: 'Duaa partagée', text, url });
  } else {
    showShareMenu(text, url, fullText);
  }
}

function showShareMenu(text, url, fullText) {
  const shareMenu = `
    <div class="duaa-share-overlay">
      <div class="duaa-share-panel">
        <h4>Partager cette duaa</h4>
        <div class="duaa-share-btns">
          <a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}" target="_blank" rel="noopener" class="duaa-btn fb">Facebook</a>
          <a href="https://twitter.com/intent/tweet?text=${encodeURIComponent(fullText)}" target="_blank" rel="noopener" class="duaa-btn tw">Twitter</a>
          <a href="https://wa.me/?text=${encodeURIComponent(fullText)}" target="_blank" rel="noopener" class="duaa-btn wa">WhatsApp</a>
          <a href="https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(fullText)}" target="_blank" rel="noopener" class="duaa-btn tg">Telegram</a>
        </div>
        <button class="duaa-close">&times;</button>
      </div>
    </div>
  `;

  const menu = document.createElement('div');
  menu.innerHTML = shareMenu;
  document.body.appendChild(menu);

  menu.querySelector('.duaa-close').onclick = () => document.body.removeChild(menu);
  menu.addEventListener('click', (e) => {
    if (e.target === menu) document.body.removeChild(menu);
  });
}

// Attacher l’événement à tous les boutons
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔌 Script de partage chargé.');
  document.querySelectorAll('.share-btn').forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      sharePreviousLetexto(e.target.closest('.share-btn'));
    });
  });
});

// Bloc Gutenberg (éditeur)
if (typeof wp !== 'undefined' && wp.domReady && wp.blocks && wp.element) {
  wp.domReady(() => {
    wp.blocks.registerBlockType('duaa/partager-duaa', {
      title: 'Partager cette duaa',
      icon: 'share',
      category: 'widgets',
      edit: () => wp.element.createElement('button', { className: 'share-btn' }, 'Partager cette duaa'),
      save: () => wp.element.createElement('button', { className: 'share-btn' }, 'Partager cette duaa')
    });
  });
}